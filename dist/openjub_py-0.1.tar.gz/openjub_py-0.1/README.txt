==========
openjub-py
==========

A Python Client for OpenJUB (https://github.com/OpenJUB/openjub-api)

INSTALL:

pip install openjub_py

TODO:

* Authentication
